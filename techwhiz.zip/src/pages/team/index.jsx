import TeamCard from "../../components/team/teamCard/TeamCard";
import TeamBackground from "../../components/team/teamBackground/TeamBackground";
import './Team.scss';
import React from 'react'
import CoreTeam from "../../components/team/CoreTeam/CoreTeam";

function Team() {
    return (
        <div className="TeamContainer">
        <CoreTeam/>
        </div>
    )
}

export default Team



