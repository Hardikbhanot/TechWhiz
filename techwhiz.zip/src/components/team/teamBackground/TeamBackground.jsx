import React from 'react'
import  './TeamBackground.scss';
function TeamBackground() {
    return (
      <div className='tBackground'>
    <section className="team-background">
      <span></span>
      <span></span>
      <span></span>
      <span></span>
      <span></span>
      <span></span>
      <span></span>
      <span></span>
      <span></span>
      <span></span>
      <span></span>
  </section>
  </div>  
    )
}

export default TeamBackground;
